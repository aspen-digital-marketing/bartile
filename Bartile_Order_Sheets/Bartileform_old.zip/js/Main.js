$(document).ready(function () {
  // Attach a click event handler to the links in the All_tabs
  $(".All_tabs a").click(function (e) {
    e.preventDefault();

    // Get the data-link attribute value of the clicked link
    var clickedLink = $(this).data("link");

    // Hide all content boxes initially
    $(".AllFrom_boxes").addClass("d-none");

    // Show the content box that matches the clicked link's data-link attribute
    $(".AllFrom_boxes[data-link='" + clickedLink + "']").removeClass("d-none");

    // Remove the 'active' class from all links and add it to the clicked link
    $(".All_tabs a").removeClass("active_From-btn");
    $(this).addClass("active_From-btn");
  });

  // Trigger click on the first link to initially display its content
  $(".All_tabs a:first").click();
});
