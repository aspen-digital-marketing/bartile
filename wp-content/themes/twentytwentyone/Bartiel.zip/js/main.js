let texture_type = [{
    "name" : "Standard-Texture",
    "url" : "img/selection/Standard-Texture.jpg"
},

{
    "name" : "Vintage",
    "url" : "img/selection/Vintage.jpg"
},

{
    "name" : "Swirl-Brush",
    "url" : "img/selection/Swirl-Brush.jpg"
}
]

let Edge_Design = [{
    "name" : "Standard-Cut",
    "url" : "img/selection/Standard-Cut.jpg"
},
{
    "name" : "Ruff-Cut",
    "url" : "img/selection/Ruff-Cut.jpg"
},

{
    "name" : "Manchester",
    "url" : "img/selection/Manchester.jpg"
}
]

let Weight_Options = [
    {
        "name" : "Super-Duty",
        "url" : "img/selection/Super-Duty.jpg"
    },
    {
        "name" : "Ultralite",
        "url" : "img/selection/Ultralite.jpg"
    },
    {
        "name" : "Standard-weight",
        "url" : "img/selection/Standard-weight.jpg"
    }
]

let Color_Options = [
    {
        "name" : "CalaisBlend",
        "url" : "img/selection/CalaisBlendEuropean.jpg"
    },
    {
        "name" : "ChateauGray",
        "url" : "img/selection/Color_ChateauGrayEuropean.jpg"
    },
    {
        "name" : "BarcelonaBlend",
        "url" : "img/selection/Color_BarcelonaBlendEuropean.jpg"
    },
    {
        "name" : "CorsicaBlend",
        "url" : "img/selection/Color_CorsicaBlendEuropean.jpg"
    },  
    {
        "name" : "GranadaRed",
        "url" : "img/selection/Color_GranadaRedEuropean.jpg"
    },
    {
        "name" : "MadridClay",
        "url" : "img/selection/Color_MadridClayEuropean.jpg"
    },
    {
        "name" : "NormadyBrown",
        "url": "img/selection/Color_NormadyBrownEuropean.jpg"
    }
]

let all_selections = [];



let edge_design;
let Weight_option;
let standard_colors
// edge_design Weight_option standard-colors

$(window).on('load',function(){
    edge_design = $("#edge_design").offset().top - 100;
    Weight_option = $("#Weight_option").offset().top - 100;
    standard_colors = $("#standard-colors").offset().top - 100;
})

// texture options

$(".texture-type").on("click",function(){
    let classes = $(this).children(".pattern-box").attr("class").split(/\s+/);

    for(let i = 0; i < texture_type.length; i++) {
        if(texture_type[i].name == classes[0]) {
            if(all_selections.indexOf(texture_type[i]) == -1) {
                all_selections.push(texture_type[i])
            }
        }
    }

    $(".texture-type").each(function(){
        if($(this).hasClass("active")) {
            let classes = $(this).children(".pattern-box").attr("class").split(/\s+/);
            for(let i = 0; i < texture_type.length; i++) {
                if(texture_type[i].name == classes[0]) {
                    if(all_selections.indexOf(texture_type[i]) != -1) {

                        let index = all_selections.indexOf(texture_type[i])
                        all_selections.splice(index, 1);
                    }
                }
            }

            $(this).removeClass("active")
        }
    })

    $(this).addClass("active");

    selection_update();

    $(".builder-options").animate({
        scrollTop: edge_design
    }, 500);

      // let edge_design;
    // let Weight_option;
    // let standard_colors
})

//Weight option

$(".Weight-type").on("click",function(){
    let classes = $(this).children(".pattern-box").attr("class").split(/\s+/);

    for(let i = 0; i < Weight_Options.length; i++) {
        if(Weight_Options[i].name == classes[0]) {
            if(all_selections.indexOf(Weight_Options[i]) == -1) {
                all_selections.push(Weight_Options[i])
            }
        }
    }

    $(".Weight-type").each(function(){
        if($(this).hasClass("active")) {
            let classes = $(this).children(".pattern-box").attr("class").split(/\s+/);
            for(let i = 0; i < Weight_Options.length; i++) {
                if(Weight_Options[i].name == classes[0]) {
                    if(all_selections.indexOf(Weight_Options[i]) != -1) {

                        let index = all_selections.indexOf(Weight_Options[i])
                        all_selections.splice(index, 1);
                    }
                }
            }

            $(this).removeClass("active")
        }
    })

    $(this).addClass("active");
   

    selection_update();

    $(".builder-options").animate({
        scrollTop: standard_colors
    }, 500);

    // let edge_design;
    // let Weight_option;
    // let standard_colors
})

//color-options

$(".color-type").on("click",function(){
    let classes = $(this).attr("class").split(/\s+/);

    for(let i = 0; i < Color_Options.length; i++) {
        if(Color_Options[i].name == classes[1]) {
            if(all_selections.indexOf(Color_Options[i]) == -1) {
                all_selections.push(Color_Options[i])
            }
        }
    }

    $(".color-type").each(function(){
        if($(this).hasClass("active")) {
            let classes = $(this).attr("class").split(/\s+/);
            for(let i = 0; i < Color_Options.length; i++) {
                if(Color_Options[i].name == classes[1]) {
                    if(all_selections.indexOf(Color_Options[i]) != -1) {

                        let index = all_selections.indexOf(Color_Options[i])
                        all_selections.splice(index, 1);
                    }
                }
            }

            $(this).removeClass("active")
        }
    })

    $(this).addClass("active");
   

    selection_update();
})








// Edge Design

$(".edge-design-type").on("click",function(){
    let classes = $(this).children(".pattern-box").attr("class").split(/\s+/);

    for(let i = 0; i < Edge_Design.length; i++) {
        if(Edge_Design[i].name == classes[0]) {
            if(all_selections.indexOf(Edge_Design[i]) == -1) {
                all_selections.push(Edge_Design[i])
            }
        }
    }

    $(".edge-design-type").each(function(){
        if($(this).hasClass("active")) {
            let classes = $(this).children(".pattern-box").attr("class").split(/\s+/);
            for(let i = 0; i < Edge_Design.length; i++) {
                if(Edge_Design[i].name == classes[0]) {
                    if(all_selections.indexOf(Edge_Design[i]) != -1) {

                        let index = all_selections.indexOf(Edge_Design[i])
                        all_selections.splice(index, 1);
                    }
                }
            }

            $(this).removeClass("active")
        }
    })

    $(this).addClass("active");
   

    selection_update();

    $(".builder-options").animate({
        scrollTop: Weight_option
    }, 500);

    // let edge_design;
    // let Weight_option;
    // let standard_colors
})




function selection_update(){
    $(".selection-options-bar").html("");
    for(let i = 0; i < all_selections.length; i++) {
        $(".selection-options-bar").append(`
        <a class="options-title"  data-zoom="img/large/Standard-Texture.jpg" data-lightbox="gallery">
        <h5>${all_selections[i].name}</h5>
        <img src="img/eye.svg" class="lightboxlightbox" onclick="gallery()"/>
        <img src="${all_selections[i].url}" data-title="${all_selections[i].name}" class="selected-img" alt="selected-img"/>
        </a>`
        )
    }
   
}

function gallery(){
    $(".lightbox").addClass("lightbox-active");
};


$(".close-btn").click(function(){
    $(".lightbox").removeClass("lightbox-active");
})

console.log("john was'nt exactly buggyman")


$(".primary-btn").click(function() {
    $(".builder-options").animate({
        scrollTop: 200
    }, 500);

});