<table id="source_configuration"></table>
<table id='slug_configuration'></table>
<label id="display_tip"></label>