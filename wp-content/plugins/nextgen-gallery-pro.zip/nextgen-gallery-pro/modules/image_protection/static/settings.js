jQuery(function($) {
    $('input[name="image_protection[protect_images]"]')
        .nextgen_radio_toggle_tr('1', $('#tr_image_protection_protect_images_globally'))
});
