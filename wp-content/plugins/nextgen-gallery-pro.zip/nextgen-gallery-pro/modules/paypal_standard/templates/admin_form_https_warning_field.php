<tr id="tr_ecommerce_paypal_std_http_warning"
    <?php if ($hidden) { ?>
        class="hidden"
    <?php } ?>
    >
    <td colspan='2'>
        <p><?php print $warning; ?></p>
    </td>
</tr>