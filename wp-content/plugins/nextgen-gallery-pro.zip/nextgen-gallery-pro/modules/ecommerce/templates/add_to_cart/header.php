<?php
/**
 * @var $i18n stdClass
 */ ?>
<thead>
    <tr>
        <th class='nggpl-quantity_field'><?php esc_html_e($i18n->quantity); ?></th>
        <th class='nggpl-description_field'><?php esc_html_e($i18n->description); ?></th>
        <th class='nggpl-price_field'><?php esc_html_e($i18n->price); ?></th>
        <th class='nggpl-total_field'><?php esc_html_e($i18n->total); ?></th>
    </tr>
</thead>
<tbody></tbody>