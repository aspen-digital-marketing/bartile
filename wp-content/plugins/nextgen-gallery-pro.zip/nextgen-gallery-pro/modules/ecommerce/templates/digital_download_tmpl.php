<script type="text/javascript">
    jQuery(function($){
        $(window).on('ngg_pro_cart.ready', function() {
        });
    });
</script>