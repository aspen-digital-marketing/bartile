jQuery(function() {
    Ngg_Pro_Cart.get_instance().empty_cart();
});