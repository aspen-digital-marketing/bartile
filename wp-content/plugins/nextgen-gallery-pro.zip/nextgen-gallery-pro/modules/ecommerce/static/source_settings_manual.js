jQuery(function($) {
    $('#manual_shipping_options').parent().css('width', 'auto');
});