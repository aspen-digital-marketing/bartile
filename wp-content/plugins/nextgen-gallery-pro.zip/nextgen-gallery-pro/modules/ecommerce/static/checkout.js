jQuery(function($) {
    const cart = new Ngg_Pro_Cart.Views.Cart();
});
